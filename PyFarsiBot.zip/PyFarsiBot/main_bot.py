import logging
import os
from datetime import datetime

import pyrogram
from pyrogram import Client, Filters

from api import *
import Drive

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
file_log_name = f"{datetime.now():%Y_%m_%d}"
if not os.path.exists('./log'):
    os.mkdir('./log')
f_handler = logging.FileHandler('./log/%s.log' % file_log_name, encoding='utf-8')
f_handler.setFormatter(formatter)
logger.addHandler(f_handler)

TYPE_EX = ['zip', 'rar', 'py', 'png', 'txt', 'pyd', 'c', 'cpp', 'pdf']

MAX_SIZE = 200

is_fa = True

PREFIX = r'(!|/)'

app = Client("myApp", api_id=973949, api_hash='8283e222a0af98281011ad54ad7a77cc')


@app.on_message(Filters.group & Filters.command('up', PREFIX) & Filters.reply)
def up(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    doc = msg.reply_to_message.document
    if doc is None:
        msg_en = 'Not a doc file'
        msg_fa = 'فقط داکیومنت رو میتوان اپلود کرد'
        msg.reply_text(msg_fa if is_fa else msg_en)
        logger.info('(Not a doc file) - GROUP: (%s, %s) - MESSAGE_ID: %s' % (msg.chat.id,
                                                                             msg.chat.title,
                                                                             msg.reply_to_message.message_id))
        return
    if doc.file_name.split('.')[-1].lower() not in TYPE_EX:
        msg_en = 'Invalid type'
        msg_fa = 'فرمت فایل برای اپلود کجاز نیست'
        msg.reply_text(msg_fa if is_fa else msg_en)
        logger.info('(Invalid type) FILE NAME: %s - FILE SIZE: %s - GROUP: (%s, %s) - MESSAGE_ID: %s' % (doc.file_name,
                                                                                                         doc.file_size,
                                                                                                         msg.chat.id,
                                                                                                         msg.chat.title,
                                                                                                         msg.reply_to_message.message_id))
        return
    size = doc.file_size / 10 ** 6
    if size > MAX_SIZE:
        msg_en = 'Out of range size (max_size: %s)' % MAX_SIZE
        msg_fa = 'حجم فایل  از محدوده %s بیشتر است' % MAX_SIZE
        msg.reply_text(msg_fa if is_fa else msg_en)
        logger.info(
            '(Out of range size) FILE NAME: %s - FILE SIZE: %s - GROUP: (%s, %s) - MESSAGE_ID: %s' % (doc.file_name,
                                                                                                      doc.file_size,
                                                                                                      msg.chat.id,
                                                                                                      msg.chat.title,
                                                                                                      msg.reply_to_message.message_id))
        return
    file_id = Drive.get_id(doc.file_name)
    if file_id is not None:
        msg_en = "file uploaded\n\nURL:   https://drive.google.com/uc?id=%s" % file_id
        msg_fa = "فایل آپلود شد.\n\nآدرس فایل:   https://drive.google.com/uc?id=%s" % file_id
        msg.reply_text(msg_fa if is_fa else msg_en)
        return

    size = '%.1f MB' % size

    msg_en = 'File = %s\nsize = %s' % (doc.file_name, size)
    msg_fa = 'نام فایل = %s\nحجم = %s' % (doc.file_name, size)
    msg_r = msg.reply_text(msg_fa if is_fa else msg_en + 'درحال دانلود ... .' if is_fa else 'downloading ... .')
    download(bot, msg)
    msg_r.edit_text(msg_fa if is_fa else msg_en + 'درحال آپلود ... .' if is_fa else 'uploading ... .')
    Drive.upload(msg.reply_to_message.document.file_name)
    file_id = Drive.get_id(doc.file_name)
    msg_r.edit_text('فایل آپلود شد.\n\nآدرس فایل:   https://drive.google.com/uc?id=%s' % file_id if is_fa else 'file uploaded\n\nURL:   https://drive.google.com/uc?id=%s')


# async def main(cli, msg):
#     await asyncio.gather(
#         download(cli, msg)
#         # pr()
#     )
#
#
# def pr():
#     while app.download_workers_list is not []:
#         print()
#         print(app.download_queue)
#         time.sleep(1)


# bot: pyrogram.client.client.Client, msg: pyrogram.Message
@app.on_message(Filters.command(['fa', 'Fa', 'FA'], PREFIX))
def set_en(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    global is_fa
    is_fa = False
    msg.reply_text('set en for language.')


@app.on_message(Filters.command(['en', 'En', 'EN'], PREFIX))
def set_fa(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    global is_fa
    is_fa = True
    msg.reply_text('زبان روی فارسی تنظیم شد.')


@app.on_message(Filters.group & Filters.command(['py2', 'python2'], PREFIX))
def python2(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    en = 'Ok, give me some Python2 code to execute.'
    msg.reply_text(en)


@app.on_message(Filters.group & Filters.command(['py3', 'python3'], PREFIX))
def python3(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    en = 'Ok, give me some Python3 code to execute.'
    msg.reply_text(en)


@app.on_message(Filters.group & Filters.reply & Filters.command(['pyf3', 'python3_file'], PREFIX))
def python2_file(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    doc = msg.reply_to_message.document
    if doc is None or doc.file_name.split('.')[-1].lower() != 'py':
        return
    download(bot, msg)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(msg, code, 'Ok, give me some Python3 code to execute.')


@app.on_message(Filters.group & Filters.reply & Filters.command(['pyf2', 'python2_file'], PREFIX))
def python2_file(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    doc = msg.reply_to_message.document
    if doc is None:
        return
    download(bot, msg)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(msg.reply_to_message, code, 'Ok, give me some Python2 code to execute.')


@app.on_message(Filters.group & Filters.text & Filters.reply)
def get_code(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    code = msg.text
    msg_reply = msg.reply_to_message.text
    print_result(msg, code, msg_reply)


def print_result(msg: pyrogram.Message, code, msg_reply):
    #     if 'import os' in code and 'Python' in msg_reply and 'Ok, give me some' in msg_reply:
    #         msg.reply_text('*Errors:*\n`%s`' % '''File "source_file.py", line 1
    #     Import os
    #             ^
    # SyntaxError: invalid syntax''', parse_mode="markdown")
    #         return
    if len(code) > 1400 or '.' not in msg_reply:
        if 'Python2' in msg_reply and 'Ok, give me some' in msg_reply:
            print('py2 fid')
            msg.reply_text(pyfiddle(code, 2, is_fa), parse_mode="markdown")
        elif 'Python3' in msg_reply and 'Ok, give me some' in msg_reply:
            print('py3 fid')
            msg.reply_text(pyfiddle(code, 3.6, is_fa), parse_mode="markdown")
    else:
        if 'Python2' in msg_reply and 'Ok, give me some' in msg_reply:
            print('py2 rex')
            msg.reply_text(rexter(code, 5), parse_mode="markdown")
        elif 'Python3' in msg_reply and 'Ok, give me some' in msg_reply:
            print('py3 rex')
            msg.reply_text(rexter(code, 24), parse_mode="markdown")


@app.on_message(Filters.group & Filters.command('pyy2', PREFIX))
def py2fid(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    en = 'Ok, give me some Python2 code to execute'
    msg.reply_text(en)


@app.on_message(Filters.group & Filters.command('pyy3', PREFIX))
def py3fid(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    en = 'Ok, give me some Python3 code to execute'
    msg.reply_text(en)


@app.on_message(Filters.group & Filters.command('pyyf3', PREFIX))
def python2_file_fid(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    doc = msg.reply_to_message.document
    if doc is None:
        return
    download(bot, msg)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(msg, code, 'Ok, give me some Python2 code to execute')


@app.on_message(Filters.group & Filters.command('pyyf2', PREFIX))
def python3_file_fid(bot: pyrogram.client.client.Client, msg: pyrogram.Message):
    doc = msg.reply_to_message.document
    if doc is None or doc.file_name.split('.')[-1].lower() != 'py':
        return
    download(bot, msg)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(msg, code, 'Ok, give me some Python3 code to execute')


@app.on_message(Filters.private & Filters.command('max_size', PREFIX))
def set_max(bot, msg):
    max_size = int(msg.text.replace(r'(/|!)max_size ', ''))
    global MAX_SIZE
    MAX_SIZE = max_size
    msg_fa = 'محدودیت اندازه روی %s MB تنظیم شد.' % MAX_SIZE
    msg_en = 'set max size (%s MB)' % MAX_SIZE
    msg.reply_text(msg_fa if is_fa else msg_en)


def download(cli, msg):
    msg.reply_text()
    cli.download_media(msg.reply_to_message.document.file_id,
                       file_name='catch/%s' % msg.reply_to_message.document.file_name)


Drive.login()
app.run()
