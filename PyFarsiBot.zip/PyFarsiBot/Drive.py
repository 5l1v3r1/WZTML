from pydrive.auth import GoogleAuth, AuthError
from pydrive.drive import GoogleDrive
import os
from threading import Thread
# from main_bot import logger


def login():
    auth = GoogleAuth()
    try:
        auth.LocalWebserverAuth()
        # logger.info('OK AUTH')
    except AuthError as e:
        # logger.error('ERROR AUTH ' + str(e))
        login()
    global drive
    drive = GoogleDrive(auth)


def get_id(file_name):
    f = open('./conf/FOLDER_ID.rez', 'r')
    FOLDER_ID = f.read()
    f.close()
    file_list = drive.ListFile({'q': "'%s' in parents and trashed=false" % FOLDER_ID}).GetList()
    for file1 in file_list:
        if file1['title'] == file_name:
            return file1['id']
    return None


def upload(file_name):
    # logger.info('START UPLOAD - FILE: %s' % file_name)
    f = open('./conf/FOLDER_ID.rez', 'r')
    FOLDER_ID = f.read()
    f.close()
    f = drive.CreateFile({"title": file_name, "parents": [{"kind": "drive#fileLink", "id": FOLDER_ID}]})
    f.SetContentFile('./catch/%s' % file_name)
    f.Upload()
    # logger.info('END UPLOAD - FILE: %s' % file_name)
    Thread(target=remove_file, args=[file_name]).start()


def remove_file(file_name):
    path = '.\\catch\\%s' % file_name
    os.remove(path)
    # logger.info('REMOVE FILE - FILE: %s' % path)
