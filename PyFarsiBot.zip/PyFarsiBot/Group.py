from typing import Union, List


class Group:
    def __init__(self,
                 chat_id: Union[int, str],
                 creator: List[Union[int, str]],
                 admins: List[Union[int, str]] = list,
                 warn_limit: int = 5,
                 is_wel: bool = True,
                 is_sticker: bool = True,
                 is_gif: bool = True,
                 is_fa: bool = True
                 ):
        self.is_fa = is_fa
        self.chat_id = chat_id
        self.creator = creator
        self.admins = admins + creator
        self.ban_list = []
        self.silence_list = []
        self.warn_dic = {}
        self.warn_limit = warn_limit
        self.is_sticker = is_sticker
        self.is_gif = is_gif
        self.is_wel = is_wel
