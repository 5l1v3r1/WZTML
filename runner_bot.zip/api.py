#!./venv/Scripts python
# -*- coding: utf-8 -*-
# CREATED BY https://t.me/rezafd

from requests import post, get
from urllib.parse import quote_plus


def rexter(code: str, v: int, is_fa: bool) -> str:
    rexter_url_api = 'https://rextester.com/rundotnet/api?LanguageChoice=%i&Program=%s'
    url_code = quote_plus(code)
    rsp = get(rexter_url_api % (24 if v != 5 else 5, url_code))
    dic = eval(rsp.text.replace('null', 'None'))
    return analyze_result(dic, v, is_fa)


def pyfiddle(code: str, v: float, is_fa: bool) -> str:
    pyfiddle_url_api = "https://pyfiddle.io/api/"
    datas = {"code": "%s" % code, "version": "%f" % 3.6 if v != 2.7 else 2.7}
    headers = {'Content-type': 'application/json'}
    rsp = post(pyfiddle_url_api, json=datas, headers=headers)
    dic = rsp.json()
    result_code = dic['output']
    msg_send_en = '*Interpreter:* Python%i\n\n*Result:*\n`%s`' % (3 if v != 2.7 else 2, result_code)
    msg_send_fa = 'اینترپرتر: Python%i\n\nنتبجه:\n%s' % (3 if v != 2.7 else 2, result_code)
    return msg_send_fa if is_fa else msg_send_en


def analyze_result(dic: dict, v, is_fa: bool) -> str:
    stats = dic['Stats']
    stats = '> ' + stats.replace(', ', '\n> ')
    warn_en = '\n\n*Warnings:*\n%s' % dic['Warnings']
    warn_fa = '\n\nاخطارها:\n%s' % dic['Warnings']
    if dic['Errors'] is not None:
        result_code = dic['Errors']
        msg_send_en = '*Interpreter:* Python%i\n\n*Errors:*\n`%s`%s\n\n*Resource Usage:*\n%s' % (3 if v != 5 else 2,result_code,
        warn_en if dic['Warnings'] is not None else '',
        stats)
        msg_send_fa = 'اینترپرتر: Python%i\n\nخطا:\n%s%s\n\nاستفاده از منابع:\n%s' % (3 if v != 5 else 2, result_code,
                                                                                      warn_fa if dic['Warnings'] is not None else '',
                                                                                      stats)
        return msg_send_fa if is_fa else msg_send_en
    else:
        result_code = dic['Result']
        msg_send_en = '*Interpreter:* Python%i\n\n*Result:*\n`%s`%s\n\n*Resource Usage:*\n%s' % (3 if v != 5 else 2,result_code,
        warn_en if dic['Warnings'] is not None else '',
        stats)
        # print(msg_send_en)
        msg_send_fa = 'اینترپرتر: Python%i\n\nنتیجه:\n%s%s\n\nاستفاده از منابع:\n%s' % (3 if v != 5 else 2, result_code,
                                                                         warn_fa if dic['Warnings'] is not None else '',
                                                                                        stats)

        return msg_send_fa if is_fa else msg_send_en
