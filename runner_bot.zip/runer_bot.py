#!./venv/Scripts/python
# -*- coding: utf-8 -*-
# CREATED BY https://t.me/rezafd

import os

import telegram

from api import *
from telegram.ext import Updater, CommandHandler, Filters, MessageHandler


def set_en(bot, update):
    global is_fa
    is_fa = False
    update.message.reply_text('set en for language.')


def python2(bot, update):
    en = 'Ok, give me some Python2 code to execute'
    update.message.reply_text(en)


def python3(bot, update):
    en = 'Ok, give me some Python3 code to execute'
    update.message.reply_text(en)

def python2_fid(bot, update):
    en = 'Ok, give me some Python2 code to execute.'
    update.message.reply_text(en)


def python3_fid(bot, update):
    en = 'Ok, give me some Python3 code to execute.'
    update.message.reply_text(en)


def python3_file(bot: telegram.bot.Bot, update):
    doc = update.message.reply_to_message.document
    if doc is None or doc.file_name.split('.')[-1].lower() != 'py':
        return
    download_file(bot, doc)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(update, code, 'Ok, give me some Python3 code to execute')


def python2_file(bot, update):
    doc = update.message.reply_to_message.document
    if doc is None:
        return
    download_file(bot, doc)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(update, code, 'Ok, give me some Python2 code to execute')

def python3_file_fid(bot: telegram.bot.Bot, update):
    doc = update.message.reply_to_message.document
    if doc is None or doc.file_name.split('.')[-1].lower() != 'py':
        return
    download_file(bot, doc)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(update, code, 'Ok, give me some Python3 code to execute.')


def python2_file_fid(bot, update):
    doc = update.message.reply_to_message.document
    if doc is None:
        return
    download_file(bot, doc)
    with open('./catch/%s' % doc.file_name, 'r', encoding='utf-8') as file:
        code = file.read()
        file.close()
    os.remove('./catch/%s' % doc.file_name)
    print_result(update, code, 'Ok, give me some Python2 code to execute.')


def download_file(bot, doc):
    print('s')
    newFile = bot.get_file(doc.file_id)
    newFile.download('./catch/%s' % doc.file_name)
    print('e')


def get_code(bot, update):
    code = update.message.text
    msg_reply = update.message.reply_to_message.text
    print_result(update, code, msg_reply)


def print_result(update, code, msg_reply):
    if 'import os' in code and 'Python' in msg_reply and ('Ok, give me some' in msg_reply):
        update.message.reply_text('*Errors:*\n`%s`' % '''File "source_file.py", line 1
    Import os
            ^
SyntaxError: invalid syntax''', parse_mode=telegram.ParseMode.MARKDOWN)
        return
    if 'Python2' in msg_reply and 'Ok, give me some' in msg_reply and '.' in msg_reply:
        print('py2 fid')
        update.message.reply_text(pyfiddle(code, 2.7, is_fa), parse_mode=telegram.ParseMode.MARKDOWN)
    elif 'Python3' in msg_reply and 'Ok, give me some' in msg_reply and '.' in msg_reply:
        print('py3 fid')
        update.message.reply_text(pyfiddle(code, 3.6, is_fa), parse_mode=telegram.ParseMode.MARKDOWN)
    if len(code) > 1400:
        if 'Python2' in msg_reply and ('Ok, give me some' in msg_reply) and '.' not in msg_reply:
            print('py2 fid')
            update.message.reply_text(pyfiddle(code, 2.7, is_fa), parse_mode=telegram.ParseMode.MARKDOWN)
        elif 'Python3' in msg_reply and ('Ok, give me some' in msg_reply) and '.' not in msg_reply:
            print('py3 fid')
            update.message.reply_text(pyfiddle(code, 3.6, is_fa), parse_mode=telegram.ParseMode.MARKDOWN)
    else:
        if 'Python2' in msg_reply and ('Ok, give me some' in msg_reply) and '.' not in msg_reply:
            print('py2 rex')
            update.message.reply_text(rexter(code, 5, is_fa), parse_mode=telegram.ParseMode.MARKDOWN)
        elif 'Python3' in msg_reply and ('Ok, give me some' in msg_reply) and '.' not in msg_reply:
            print('py3 rex')
            update.message.reply_text(rexter(code, 24, False), parse_mode=telegram.ParseMode.MARKDOWN)


if __name__ == '__main__':
    is_fa = False
    if not os.path.exists('./catch'):
        os.mkdir('./catch')
    f = open('./conf/TOKEN.rez', 'r')
    TOKEN = f.read()
    f.close()
    updater = Updater(TOKEN)
    dp = updater.dispatcher
    dp.add_handler(MessageHandler(filters=(Filters.group & Filters.text & Filters.reply), callback=get_code))
    dp.add_handler(CommandHandler('python3', python3, Filters.group))
    dp.add_handler(CommandHandler('py3', python3, Filters.group))
    dp.add_handler(CommandHandler('pyy3', python3_fid, Filters.group))
    dp.add_handler(CommandHandler('python2', python2, Filters.group))
    dp.add_handler(CommandHandler('py2', python2, Filters.group))
    dp.add_handler(CommandHandler('pyy2', python2_fid, Filters.group))
    dp.add_handler(CommandHandler('python3_file', python3_file, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('py3_file', python3_file, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('pyyf3', python3_file_fid, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('pyf3', python3_file, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('python2_file', python2_file, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('pyf2', python2_file, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('pyyf2', python2_file_fid, (Filters.group & Filters.reply)))
    dp.add_handler(CommandHandler('py2_file', python2_file, (Filters.group & Filters.reply)))
    updater.start_polling()
    updater.idle()
